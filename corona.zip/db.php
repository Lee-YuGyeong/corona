﻿<?php
	header('Content-Type: text/html; charset=utf-8'); // utf-8인코딩

	$db = mysqli_connect("localhost", "root", "dldbrud12!", "corona");

	function mq($sql)
	{
		global $db;
		return $db->query($sql);
	}

?>
