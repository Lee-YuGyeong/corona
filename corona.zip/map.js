/**
 * ---------------------------------------
 * This demo was created using amCharts 4.
 *
 * For more information visit:
 * https://www.amcharts.com/
 *
 * Documentation is available at:
 * https://www.amcharts.com/docs/v4/
 * ---------------------------------------
 */
// Create map instance



var chart = am4core.create("chartdiv", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_southKoreaHigh;

// Set projection
chart.projection = new am4maps.projections.Miller();
chart.panBehavior = "rotateLongLat";
chart.maxZoomLevel = 1;

// Create map polygon series
var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());
polygonSeries.useGeodata = true;

// Configure series
var polygonTemplate = polygonSeries.mapPolygons.template;
polygonTemplate.tooltipText = "{name}";

polygonTemplate.fill = am4core.color("#d4edda");
polygonTemplate.events.on("hit", function(ev) {
  var data = ev.target.dataItem.dataContext;
  var citytext = document.getElementById("citytext");
  var peopletext = document.getElementById("peopletext");
   citytext.innerHTML =  data.name;
   peopletext.innerHTML = data.description;
});

polygonTemplate.events.on("hit", function(ev) {
  var data = ev.target.dataItem.dataContext;
  var info = document.getElementById("info");
   info.innerHTML = "<h3>" + data.name + "</h3>";
  if (data.description) {
    info.innerHTML += data.description;
  }
  else {
    info.innerHTML += "<i>No description provided.</i>"
  }
});


var hs = polygonTemplate.states.create("hover");
hs.properties.fill = am4core.color("#367B25");
