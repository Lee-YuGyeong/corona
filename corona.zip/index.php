<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->

  <?php  require_once 'db.php'; ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <script src="CountUP/countUp.min.js"></script>
  <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
  <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/libs/css/style.css">
  <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
  <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
  <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
  <link rel="stylesheet" href="mapstyle.css?after">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.10/c3.min.js"></script>
  <link rel="stylesheet" href="test2.css">
  <script src="https://www.amcharts.com/lib/4/core.js"></script>
  <script src="https://www.amcharts.com/lib/4/maps.js"></script>
  <script src="citynum.php"></script>
    <script src="southKoreaHigh.js?ver=1"></script>

  <title>코로나 바이러스 통계표</title>

  <?php
  $result=mq("select * from people");
  $row = mysqli_fetch_array($result);
  $row[4]=array();
  ?>

  <script type="text/javascript">
  window.onload = function(){
    var options = {
      useEasing : true,
      useGrouping : true,
      separator : ',',
      decimal : '.',
      prefix : '',
      suffix : ''
    };
    var demo = new CountUp("myTargetElement", 0,<?php  echo $row[0]; ?>, 0, 2.5, options);        //확진환자 업데이트
    var demo2 = new CountUp("myTargetElement2", 0, <?php  echo $row[2]; ?>, 0, 2.5, options);        //검사진행자 업데이트
    var demo3 = new CountUp("myTargetElement3", 0, <?php  echo $row[1]; ?>, 0, 2.5, options);          //퇴원환자 업데이
    var demo4 = new CountUp("myTargetElement4", 0, <?php  echo $row[3]; ?>, 0, 2.5, options);          //사망자 수 업데이트
    demo.start();
    demo2.start();
    demo3.start();
    demo4.start();
  }
  </script>
<?php $color = "red"; ?>
 <script type="text/javascript">
  var color = "<?= $color ?>";


 </script>

  <script type="text/javascript">
    function myFunction(s, c) {
      var x = document.getElementById("peopletext");
      var y = document.getElementById("citytext");
      x.innerHTML = s;
      y.innerHTML = c;
    }
    </script>

</head>

<body>
  <div class="dashboard-main-wrapper">
    <div class="dashboard-header">
      <nav class="navbar navbar-expand-lg bg-white fixed-top">
        <a class="navbar-brand" href="index.php">Corona</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto navbar-right-top">
            <li class="nav-item dropdown notification">
              <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span class="indicator"></span></a>
              <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                <li>
                  <div class="notification-title"> Notification</div>
                  <div class="notification-list">
                    <div class="list-group">
                      <a href="#" class="list-group-item list-group-item-action active">
                        <div class="notification-info">
                          <div class="notification-list-user-img"><img src="assets/images/avatar-2.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                          <div class="notification-list-user-block"><span class="notification-list-user-name">Admin</span>모든정보는 실시간으로 반영됩니다.</div>
                        </div>
                      </a>
                      <a href="#" class="list-group-item list-group-item-action">
                        <div class="notification-info">
                          <div class="notification-list-user-img"><img src="assets/images/avatar-3.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                          <div class="notification-list-user-block"><span class="notification-list-user-name">Admin </span>부족한 부분이 많습니다.이해해주세요.</div>
                        </div>
                      </a>
                    </div>
                  </div>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown connection">
              <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
              <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                <li class="connection-list">
                  <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/github.png" alt=""> <span>Github</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/dribbble.png" alt=""> <span>Dribbble</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/dropbox.png" alt=""> <span>Dropbox</span></a>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/bitbucket.png" alt=""> <span>Bitbucket</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/mail_chimp.png" alt=""><span>Mail chimp</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/slack.png" alt=""> <span>Slack</span></a>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="conntection-footer"><a href="#">More</a></div>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown nav-user">
              <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle"></a>
              <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                <div class="nav-user-info">
                  <h5 class="mb-0 text-white nav-user-name">John Abraham </h5>
                  <span class="status"></span><span class="ml-2">Available</span>
                </div>
                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </div>

    <div class="nav-left-sidebar sidebar-dark">
      <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
          <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav flex-column">
              <li class="nav-divider">
                Menu
              </li>
              <li class="nav-item ">
                <a class="nav-link active" href="#"><i class="fa fa-fw fa-user-circle"></i>국내 정보 <span class="badge badge-success">6</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cityindex.php"><i class="fa fa-fw fa-rocket"></i>지역별현황</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="worldindex.php"><i class="fa fa-fw fa-rocket"></i>나라별현황</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="ecommerce-product.html" ><i class="fas fa-fw fa-chart-pie"></i>마스크구매</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://dj.kbs.co.kr/resources/2020-02-03/index.php?city=%EB%B6%80%EC%82%B0" target="_blank"><i class="fas fa-fw fa-chart-pie"></i>확진자동선</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://www.mohw.go.kr/react/popup_200128.html" target="_blank" ><i class="fas fa-fw fa-chart-pie"></i>주변선별진료소</a>
              </li>

              <li class="nav-divider">
                Features
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-6" aria-controls="submenu-6"><i class="fas fa-fw fa-file"></i> Pages </a>
                <div id="submenu-6" class="collapse submenu" style="">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link" href="pages/blank-page.html">Blank Page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/blank-page-header.html">Blank Page Header</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/login.html">Login</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/404-page.html">404 page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/sign-up.html">Sign up Page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/forgot-password.html">Forgot Password</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/pricing.html">Pricing Tables</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/timeline.html">Timeline</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/calendar.html">Calendar</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/sortable-nestable-lists.html">Sortable/Nestable List</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/widgets.html">Widgets</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/media-object.html">Media Objects</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/cropper-image.html">Cropper</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/color-picker.html">Color Picker</a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="influencer-finder.html"><i class="fas fa-fw fa-map-marker-alt"></i>Developers</a>
                <div id="submenu-9" class="collapse submenu" style="">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link" href="pages/map-google.html">Google Maps</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/map-vector.html">Vector Maps</a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
    <!-- ============================================================== -->
    <!-- end left sidebar -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- wrapper  -->
    <!-- ============================================================== -->
    <div class="dashboard-wrapper">
      <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
          <!-- ============================================================== -->
          <!-- pageheader  -->
          <!-- ============================================================== -->
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="page-header">
                <h2 class="pageheader-title">국내환자 통계자료(Last update. <?php  echo $row['date']; ?>) </h2>  <!--업데이트 날짜-->
                <div class="page-breadcrumb">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                      <li class="breadcrumb-item active" aria-current="page">E-Commerce Dashboard Template</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>

          <div class="ecommerce-widget">
            <div class="row">
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="text-muted">확진자</h5>
                    <div class="metric-value d-inline-block">
                      <h1 id="myTargetElement" class="mb-1">0</h1>
                    </div>
                    <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                      <span><i class="fa fa-fw fa-arrow-up"></i></span><span><?php echo $row['newill'] ?></span>
                    </div>
                  </div>
                  <div id="sparkline-revenue"></div>
                </div>
              </div>

              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="text-muted">사망자</h5>
                    <div class="metric-value d-inline-block">
                      <h1 id="myTargetElement2" class="mb-1">0</h1>
                    </div>
                    <div class="metric-label d-inline-block float-right text-primary font-weight-bold">
                      <span>N/A</span>
                    </div>
                  </div>
                  <div id="sparkline-revenue2"></div>
                </div>
              </div>

              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="text-muted">완치자</h5>
                    <div class="metric-value d-inline-block">
                      <h1 id="myTargetElement3" class="mb-1">0</h1>
                    </div>
                    <div class="metric-label d-inline-block float-right text-secondary font-weight-bold">
                      <span>-2.00%</span>
                    </div>
                  </div>
                  <div id="sparkline-revenue3"></div>
                </div>
              </div>

              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="text-muted">검사진행자</h5>
                    <div class="metric-value d-inline-block">
                      <h1 id="myTargetElement4" class="mb-1">0</h1>
                    </div>
                    <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                      <span><i class="fa fa-fw fa-arrow-up"></i></span><span>5.86%</span>
                    </div>
                  </div>
                  <div id="sparkline-revenue4"></div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="card">
                  <h5 class="card-header">지도를 클릭하시면 확진자 인원이 표시됩니다.</h5>
                  <div class="card-body" style="height:635px">
                    <div class="mapdiv">
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-9 col-9 bigbox">
                        <div class="card">
                        <h5 class="card-header citybox" id="citytext">지역</h5>
                          <div class="card-body peoplebox" id="peopletext">확진자 수</div>
                        </div>
                      </div>


                      </div>
  <div id="chartdiv">
                    </div>


                  </div>

                  <a href="cityindex.php" class=" card-header cityindexbox" style="text-align: center;">지역별 정보 보기</a>

                </div>
              </div>


              <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="card">
                  <h5 class="card-header">주간그래프</h5>
                  <div class="card-body">
                    <div id="c3chart"></div>
                    <script type="text/javascript">
                      var chart = c3.generate({
                        bindto: '#c3chart',
                        data: {
                          x: 'x',
                          columns: [
                            ['x', '2020-01-20','2020-01-24','2020-01-26','2020-01-27','2020-01-30','2020-01-31','2020-02-01', '2020-02-02', '2020-02-04', '2020-02-05', '2020-02-06', '2020-02-09', '2020-02-10', '2020-02-16', '2020-02-18', '2020-02-19','2020-02-20','2020-02-21','2020-02-22','2020-02-23','2020-02-24',
                          '2020-02-25','2020-02-26','2020-02-27','2020-02-28','2020-02-29','2020-03-01','2020-00-00'],
                            ['감염자 수', 1, 2, 3, 4, 7, 11, 12, 15, 16, 21, 24, 27,28,30,31,51,104,204,433,602,833,977,1261,1595,2022,2931,3526]
                          ],
                          type: 'spline',
                          colors: {
                            x: '#49e009',
                          }
                        },
                        axis: {
                          x: {
                            type: 'timeseries',
                            tick: {
                              count: 15,
                              format: '%m-%d',
                              rotate:-25,
                              multiline: false
                            },
                            height:35
                          }
                        }
                      });
                    </script>
                  </div>
                </div>

                <?php
                for($i=0;$i<10;$i++){
                  $result=mq("select * from `world` order by ill desc, death desc limit $i,1");
                  $row[$i] = mysqli_fetch_array($result);
                } ?>
                <div class="card">
                   <h5 class="card-header" style="font-weight:bold text-align:center">국외현황</h5>
                  <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table no-wrap p-table">
                        <thead class="bg-light">
                          <tr class="border-0" >
                            <th class="border-0">순위</th>
                            <th class="border-0">국가</th>
                            <th class="border-0">확진자</th>
                            <th class="border-0">사망자</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>#1</td>
                            <td><?php echo $row[0][1];  ?></td>
                            <td><?php echo $row[0][2],"명" ?></td>
                            <td><?php echo $row[0][3],"명"?></td>
                          </tr>
                          <tr>
                            <td>#2</td>
                            <td><?php echo $row[1][1]; ?></td>
                            <td><?php echo $row[1][2],"명"; ?></td>
                            <td><?php echo $row[1][3],"명"; ?></td>
                          </tr>
                          <tr>
                            <td>#3</td>
                            <td><?php echo $row[2][1]; ?> </td>
                            <td><?php echo $row[2][2],"명"; ?></td>
                            <td><?php echo $row[2][3],"명"; ?></td>
                          </tr>
                          <tr>
                            <td>#4</td>
                            <td><?php echo $row[3][1]; ?> </td>
                            <td><?php echo $row[3][2],"명"; ?></td>
                            <td><?php echo $row[3][3],"명"; ?></td>
                          </tr>
                          <tr>
                            <td>#5</td>
                            <td> <?php echo $row[4][1]; ?></td>
                            <td><?php echo $row[4][2],"명"; ?></td>
                            <td><?php echo $row[4][3],"명"; ?></td>
                          </tr>


                        </tbody>
                      </table>
                    </div>
                  </div>
                  <a href="worldindex.php" class=" card-header cityindexbox" style="text-align: center;">나라별 정보 더 보기</a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- ============================================================== -->
  <!-- Optional JavaScript -->
  <script src="map.js?ver=1"></script>
  <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
  <script src="assets/libs/js/main-js.js"></script>
  <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
  <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
  <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>

</html>
