  <?php  require_once 'db.php'; ?>



<?php
$color = "999";
echo $a[1];

  for($count=1;$count<18;$count++){
    $result=mq("select * from city where num=$count");
    $row[$count] = mysqli_fetch_array($result);
  //  $country[$count] = array('ill'=>$row[$count]['ill']);

}
    echo $row[1][2];
?>
