<!doctype html>
<html lang="en">
<head>
  <?php  require_once 'db.php'; ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
  <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/libs/css/style.css">
  <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
  <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
  <link rel="stylesheet" href="mapstyle.css?after">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.10/c3.min.js"></script>
  <title>코로나 바이러스 통계표</title>
</head>


<body>
  <div class="dashboard-main-wrapper">
    <div class="dashboard-header">
      <nav class="navbar navbar-expand-lg bg-white fixed-top">
        <a class="navbar-brand" href="index.php">Corona</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto navbar-right-top">
            <li class="nav-item dropdown notification">
              <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span class="indicator"></span></a>
              <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                <li>
                  <div class="notification-title"> Notification</div>
                  <div class="notification-list">
                    <div class="list-group">
                      <a href="#" class="list-group-item list-group-item-action active">
                        <div class="notification-info">
                          <div class="notification-list-user-img"><img src="assets/images/avatar-2.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                          <div class="notification-list-user-block"><span class="notification-list-user-name">Admin</span>모든정보는 실시간으로 반영됩니다.</div>
                        </div>
                      </a>
                      <a href="#" class="list-group-item list-group-item-action">
                        <div class="notification-info">
                          <div class="notification-list-user-img"><img src="assets/images/avatar-3.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                          <div class="notification-list-user-block"><span class="notification-list-user-name">Admin </span>부족한 부분이 많습니다.이해해주세요.</div>
                        </div>
                      </a>
                    </div>
                  </div>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown connection">
              <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
              <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                <li class="connection-list">
                  <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/github.png" alt=""> <span>Github</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/dribbble.png" alt=""> <span>Dribbble</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/dropbox.png" alt=""> <span>Dropbox</span></a>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/bitbucket.png" alt=""> <span>Bitbucket</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/mail_chimp.png" alt=""><span>Mail chimp</span></a>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                      <a href="#" class="connection-item"><img src="assets/images/slack.png" alt=""> <span>Slack</span></a>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="conntection-footer"><a href="#">More</a></div>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown nav-user">
              <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle"></a>
              <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                <div class="nav-user-info">
                  <h5 class="mb-0 text-white nav-user-name">John Abraham </h5>
                  <span class="status"></span><span class="ml-2">Available</span>
                </div>
                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </div>
    <div class="nav-left-sidebar sidebar-dark">
      <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
          <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav flex-column">
              <li class="nav-divider">
                Menu
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="index.php" ><i class="fa fa-fw fa-user-circle"></i>국내 정보 <span class="badge badge-success">6</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="cityindex"><i class="fa fa-fw fa-rocket"></i>지역별현황</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="worldindex.php"><i class="fa fa-fw fa-rocket"></i>나라별현황</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="ecommerce-product.html" ><i class="fas fa-fw fa-chart-pie"></i>마스크구매</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://dj.kbs.co.kr/resources/2020-02-03/index.php?city=%EB%B6%80%EC%82%B0" target="_blank"><i class="fas fa-fw fa-chart-pie"></i>확진자동선</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://www.mohw.go.kr/react/popup_200128.html" target="_blank" ><i class="fas fa-fw fa-chart-pie"></i>주변선별진료소</a>
              </li>
              <li class="nav-divider">
                Features
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-6" aria-controls="submenu-6"><i class="fas fa-fw fa-file"></i> Pages </a>
                <div id="submenu-6" class="collapse submenu" style="">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link" href="pages/blank-page.html">Blank Page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/blank-page-header.html">Blank Page Header</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/login.html">Login</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/404-page.html">404 page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/sign-up.html">Sign up Page</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/forgot-password.html">Forgot Password</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/pricing.html">Pricing Tables</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/timeline.html">Timeline</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/calendar.html">Calendar</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/sortable-nestable-lists.html">Sortable/Nestable List</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/widgets.html">Widgets</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/media-object.html">Media Objects</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/cropper-image.html">Cropper</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/color-picker.html">Color Picker</a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="influencer-finder.html"><i class="fas fa-fw fa-map-marker-alt"></i>Developers</a>
                <div id="submenu-9" class="collapse submenu" style="">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link" href="pages/map-google.html">Google Maps</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="pages/map-vector.html">Vector Maps</a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>

    <div class="dashboard-wrapper">
      <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
            <?php
              for($count=1;$count<18;$count++){
                 $result=mq("select * from city where num=$count");
                 $row[$count] = mysqli_fetch_array($result);
                 $city[$count] = array('ill'=>$row[$count]['ill'],'clean'=>$row[$count]['clean'],'death'=>$row[$count]['death'],'ing'=>$row[$count]['ing']);
              } ?>
    <h3 style="color:#3d405c; font-weight:bold; text-align: center;">버튼을 누르면 해당 지역으로 이동됩니다</h3>
                  <hr>
          <div class="row">
                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
                  <div class="sidebar-nav-fixed">
                    <div class="card">
                      <a href="#1" class="card-header page selectbox active">서울</a>
                    </div>
                 </div>
               </div>

              <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
                <div class="sidebar-nav-fixed">
                  <div class="card">
                    <a href="#2" class="card-header page selectbox active">부산</a>
                  </div>
               </div>
             </div>

            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
              <div class="sidebar-nav-fixed">
                <div class="card">
                  <a href="#3" class="card-header page selectbox active">대구</a>
                </div>
            </div>
          </div>

          <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
            <div class="sidebar-nav-fixed">
              <div class="card">
                <a href="#4" class="card-header page selectbox active">인천</a>
              </div>
          </div>
        </div>

        <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
          <div class="sidebar-nav-fixed">
            <div class="card">
              <a href="#5" class="card-header page selectbox active">광주</a>
            </div>
        </div>
      </div>

      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
        <div class="sidebar-nav-fixed">
          <div class="card">
            <a href="#6" class="card-header page selectbox active">대전</a>
          </div>
      </div>
    </div>

    <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
      <div class="sidebar-nav-fixed">
        <div class="card">
          <a href="#7" class="card-header page selectbox active">울산</a>
        </div>
    </div>
  </div>

  <div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
    <div class="sidebar-nav-fixed">
      <div class="card">
        <a href="#8" class="card-header page selectbox active">세종</a>
      </div>
  </div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#9" class="card-header page selectbox active">경기</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#10" class="card-header page selectbox active">강원</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#11" class="card-header page selectbox active">충북</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#12" class="card-header page selectbox active">충남</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#13" class="card-header page selectbox active">전북</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#14" class="card-header page selectbox active">전남</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#15" class="card-header page selectbox active">경북</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#16" class="card-header page selectbox active">경남</a>
    </div>
</div>
</div>

<div class="col-xl-2 col-lg-2 col-md-3 col-sm-3 col-3">
  <div class="sidebar-nav-fixed">
    <div class="card">
      <a href="#17" class="card-header page selectbox active">제주</a>
    </div>
</div>
</div>
          </div>

          <hr>

          <div class="row ">

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12"  id="1" >
              <div class="card">
                <h5 class="card-header cityname ">서울</h5>
                <div class="card-body p-0">

                  <ul class="social-sales list-group list-group-flush">
                    <li class="list-group-item social-sales-content">

                      <div class="row">

                      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                        <div>확진자</div>
                        <div class="citynumdetail"><?php echo $city[1]['ill']?></div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                      <div>사망자</div>
                      <div><?php echo $city[1]['death']?></div>
                    </div>
                    </div>

                    </li>
                    <li class="list-group-item social-sales-content">
                      <div class="row">

                      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                        <div>완치자</div>
                        <div class="citynumdetail"><?php echo $city[1]['clean']?></div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                      <div>검사진행</div>
                      <div><?php echo $city[1]['ing']?></div>
                    </div>
                    </div>

                    </li>



                    <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45" ><span class="social-sales-name" ><a href="http://www.seoul.go.kr/coronaV/coronaStatus.do" target="_blank" class="link" >  서울특별시 코로나 홈페이지 바로가기</a></span>
                    </li>
                  </ul>
                </div>


              </div>
            </div>

            <div class="col-xl-6 col-lg-6 col-md-12 col-s" id="2">
              <div class="card" >
                <h5 class="card-header cityname">부산</h5>
                <div class="card-body p-0">

                  <ul class="social-sales list-group list-group-flush">
                    <li class="list-group-item social-sales-content">

                      <div class="row">

                      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                        <div>확진자</div>
                        <div class="citynumdetail"><?php echo $city[2]['ill']?></div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                      <div>사망자</div>
                      <div><?php echo $city[2]['death']?></div>
                    </div>
                    </div>

                    </li>
                    <li class="list-group-item social-sales-content">
                      <div class="row">

                      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                        <div>완치자</div>
                        <div class="citynumdetail"><?php echo $city[2]['clean']?></div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                      <div>검사진행</div>
                      <div><?php echo $city[2]['ing']?></div>
                    </div>
                    </div>

                    </li>


                    <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.busan.go.kr/corona/index.jsp"  target="_blank" class="link" >  부산광역시 코로나 홈페이지 바로가기</a></span>
                    </li>
                  </ul>
                </div>


              </div>
            </div>



          </div>



      <!-- ============================================================== -->


      <div class="row" >

        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-1"id="3">
          <div class="card">
            <h5 class="card-header cityname"  >대구</h5>
            <div class="card-body p-0">

              <ul class="social-sales list-group list-group-flush">
                <li class="list-group-item social-sales-content">

                  <div class="row">

                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                    <div>확진자</div>
                    <div class="citynumdetail"><?php echo $city[3]['ill']?></div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                  <div>사망자</div>
                  <div><?php echo $city[3]['death']?></div>
                </div>
                </div>

                </li>
                <li class="list-group-item social-sales-content">
                  <div class="row">

                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                    <div>완치자</div>
                    <div class="citynumdetail"><?php echo $city[3]['clean']?></div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                  <div>검사진행</div>
                  <div><?php echo $city[3]['ing']?></div>
                </div>
                </div>

                </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.daegu.go.kr/" target="_blank" class="link">  대구광역시 코로나 홈페이지 바로가기</a></span>

                </li>
              </ul>
            </div>


          </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="4">
          <div class="card">
            <h5 class="card-header cityname" >인천</h5>
            <div class="card-body p-0">

              <ul class="social-sales list-group list-group-flush">
                <li class="list-group-item social-sales-content">

                  <div class="row">

                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                    <div>확진자</div>
                    <div class="citynumdetail"><?php echo $city[4]['ill']?></div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                  <div>사망자</div>
                  <div><?php echo $city[4]['death']?></div>
                </div>
                </div>

                </li>
                <li class="list-group-item social-sales-content">
                  <div class="row">

                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                    <div>완치자</div>
                    <div class="citynumdetail"><?php echo $city[4]['clean']?></div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
                  <div>검사진행</div>
                  <div><?php echo $city[4]['ing']?></div>
                </div>
                </div>

                </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://ncov.mohw.go.kr/bdBoardList_Real.do?brdId=1&brdGubun=13&ncvContSeq=&contSeq=&board_id=&gubun=" target="_blank"class="link" >  인천광역시 코로나 홈페이지 바로가기</a></span>

                </li>
              </ul>
            </div>


          </div>
        </div>



      </div>



  <!-- ============================================================== -->


  <div class="row">

    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="5">
      <div class="card">
        <h5 class="card-header cityname" >광주</h5>
        <div class="card-body p-0">

          <ul class="social-sales list-group list-group-flush">
            <li class="list-group-item social-sales-content">

              <div class="row">

              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                <div>확진자</div>
                <div class="citynumdetail"><?php echo $city[5]['ill']?></div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
              <div>사망자</div>
              <div><?php echo $city[5]['death']?></div>
            </div>
            </div>

            </li>
            <li class="list-group-item social-sales-content">
              <div class="row">

              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                <div>완치자</div>
                <div class="citynumdetail"><?php echo $city[5]['clean']?></div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
              <div>검사진행</div>
              <div><?php echo $city[5]['ing']?></div>
            </div>
            </div>

            </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://www.gwangju.go.kr/" target="_blank" class="link"> 광주광역시  코로나 홈페이지 바로가기</a></span>

            </li>
          </ul>
        </div>


      </div>
    </div>

    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="6">
      <div class="card">
        <h5 class="card-header cityname">대전</h5>
        <div class="card-body p-0">

          <ul class="social-sales list-group list-group-flush">
            <li class="list-group-item social-sales-content">

              <div class="row">

              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
                <div>확진자</div>
                <div class="citynumdetail"><?php echo $city[6]['ill']?></div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
              <div>사망자</div>
              <div><?php echo $city[6]['death']?></div>
            </div>
            </div>

            </li>
            <li class="list-group-item social-sales-content">
              <div class="row">

              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
                <div>완치자</div>
                <div class="citynumdetail"><?php echo $city[6]['clean']?></div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
              <div>검사진행</div>
              <div><?php echo $city[6]['ing']?></div>
            </div>
            </div>

            </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://www.daejeon.go.kr/corona19/index.do" target="_blank"class="link" >  대전광역시 코로나 홈페이지 바로가기</a></span>

            </li>
          </ul>
        </div>


      </div>
    </div>



  </div>



<!-- ============================================================== -->



<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-1" id="7">
    <div class="card">
      <h5 class="card-header cityname" >울산</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[7]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[7]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[7]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[7]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.ulsan.go.kr/corona.jsp" target="_blank" class="link">  울산광역시 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="8">
    <div class="card">
      <h5 class="card-header cityname" >세종</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[8]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[8]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[8]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[8]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://www.sejong.go.kr/life/sub05_0704.do" target="_blank" class="link">  세종특별자치시 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>



</div>



<!-- ============================================================== -->



<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="9">
    <div class="card">
      <h5 class="card-header cityname" >경기</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[9]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[9]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[9]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[9]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://www.gg.go.kr/bbs/boardView.do?bsIdx=464&bIdx=2296956&menuId=1535" target="_blank"class="link" >  경기도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="10">
    <div class="card">
      <h5 class="card-header cityname">강원</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[10]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[10]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[10]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[10]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.provin.gangwon.kr/gw/portal" target="_blank" class="link">  강원도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>



</div>



<!-- ============================================================== -->


<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="11">
    <div class="card">
      <h5 class="card-header cityname">충북</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[11]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[11]['clean']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[11]['death']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[11]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.chungbuk.go.kr/www/covid-19/index.html" target="_blank" class="link">  충청북도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="12">
    <div class="card">
      <h5 class="card-header cityname">충남</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[12]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[12]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[12]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[12]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.chungnam.go.kr/" target="_blank"class="link">  충청남도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>



</div>



<!-- ============================================================== -->


<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="13">
    <div class="card">
      <h5 class="card-header cityname">전북</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[13]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[13]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[13]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[13]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.jeonbuk.go.kr/" target="_blank" class="link">  전라북도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="14">
    <div class="card">
      <h5 class="card-header cityname">전남</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[14]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[14]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[14]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[14]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://www.jeonnam.go.kr/" target="_blank" class="link">  전라남도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>



</div>



<!-- ============================================================== -->


<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="15">
    <div class="card">
      <h5 class="card-header cityname">경북</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[15]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[15]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[15]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[15]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.gb.go.kr/Main/index.html" target="_blank" class="link">  경상북도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="16">
    <div class="card">
      <h5 class="card-header cityname">경남</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[16]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[16]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[16]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[16]['ing']?></div>
          </div>
          </div>

          </li>


  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="http://www.gyeongnam.go.kr/corona.html" target="_blank" class="link">  경상남도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>



</div>



<!-- ============================================================== -->


<div class="row">

  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" id="17">
    <div class="card">
      <h5 class="card-header cityname">제주</h5>
      <div class="card-body p-0">

        <ul class="social-sales list-group list-group-flush">
          <li class="list-group-item social-sales-content">

            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;" >
              <div>확진자</div>
              <div class="citynumdetail"><?php echo $city[17]['ill']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>사망자</div>
            <div><?php echo $city[17]['death']?></div>
          </div>
          </div>

          </li>
          <li class="list-group-item social-sales-content">
            <div class="row">

            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum" style="  border-right: 1px solid #e6e6f2;">
              <div>완치자</div>
              <div class="citynumdetail"><?php echo $city[17]['clean']?></div>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 citynum">
            <div>검사진행</div>
            <div><?php echo $city[17]['ing']?></div>
          </div>
          </div>

          </li>
  <li class="list-group-item social-sales-content"><img src="assets/images/domain.png" alt="" width="45"><span class="social-sales-name" ><a href="https://jeju.go.kr/covid19.jsp" target="_blank" class="link">  제주특별자치도 코로나 홈페이지 바로가기</a></span>

          </li>
        </ul>
      </div>


    </div>
  </div>

</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
  <script src="assets/libs/js/main-js.js"></script>
</body>

</html>
